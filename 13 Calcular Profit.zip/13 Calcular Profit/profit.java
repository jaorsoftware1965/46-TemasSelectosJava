// -------------------------------------------------------
// Tarea de Java 01
// Calculo de Profit
// -------------------------------------------------------
	
// Librerías
import javax.swing.*;

public class profit extends JFrame
{
	// Propiedades de la Clase
	private JLabel lblProfit;
	private JList  lstProfit;

	// Constructor
    public profit(Double valor) 
	{
		// Establece Null Layout
        setLayout(null);
        
		// crea una etiqueta
		lblProfit = new JLabel("Profit:");
        lblProfit.setBounds(10,20,300,30);
        add(lblProfit);

		// Cre la Lista
		lstProfit = new JList();

		// Crea el Modelo para la Lista
        DefaultListModel modelo = new DefaultListModel();

		// Agrega el profit a JList
        modelo.addElement(String.valueOf(valor));
        lstProfit.setModel(modelo);

		lstProfit.setBounds(100,20,100,30);
        add(lstProfit);
    }

    public static void main(String[] ar) 
	{
        // Declara las variables indicadas en el ejercicio
		// a) Declara las variables revenue,cost y profit de tipo Double
		double revenue, cost, profit;

		// b) Asignar el Valor 98456 a la variable revenue
		revenue = 98456;

        // c) Asignar el Valor 45000 a la variable cost
		cost = 45000;

        // d) Asignar la diferencia entre la variable revenue y cost a la variable profit
		profit = revenue - cost;
        
		// e) Desplegar el valor de la variable profit en un listbox

		// Creamos la Ventana pasando el valor como parametros
        profit ventana = new profit(profit);

		// Colocamos el titulo
		ventana.setTitle("Calculo de Profit");
		
		// Establecemos dimensiones
        ventana.setBounds(10,20,400,300);

		// La hacemos visible
        ventana.setVisible(true);

		// Establecemos que sucede al cerrar la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}