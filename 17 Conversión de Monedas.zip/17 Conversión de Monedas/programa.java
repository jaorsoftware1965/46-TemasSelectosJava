// -------------------------------------------------------
// PROBLEMAS INTERACTIVO DE CONVERSION DE MONEDAS
// Programa 06
// A usted lo han seleccionado para trabajar en un programa 
// interactivo. 
// Realice una busqueda por Internet sobre la conversion de
// monedas. Luego prepare un programa para realizar la 
// conversión del Dolar Americano a los siguientes:
// Libras Britanicas
// Peso Mexicano
// Yen Japones
// El Diseño de la Pantalla debe ser similar al siguiente:

// Conversion del Dolar Americano
// 1.- Libras Britanicas
// 2.- Pesos Mexicanos
// 3.- Yen Japones

// Entre 1,2,3:____
// Entre la Cantidad de Dolares Americanos:___
// El Equivalente es de:_____

// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Valores de las Monedas
    static final private Double valLibraPorDolar =  00.72;
    static final private Double valPesoPorDolar  =  20.05;
    static final private Double valYenPorDolar   = 108.77;

    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
                
        // Mensajes
        System.out.println("Conversion del Dolar Americano");
        System.out.println("1.- Libras Britanicas");
        System.out.println("2.- Pesos  Mexicanos");
        System.out.println("3.- Yen Japones");
        System.out.println("");
         
        System.out.print("Entre 1,2,3:");
        Integer moneda = oEntrada.nextInt(); 
        
        System.out.print("Entre la Cantidad de Dolares Americanos:");
        Double  dolares = oEntrada.nextDouble(); 
        Double conversion = 0.0;
        
        // Verifica la Moneda
        switch (moneda)
        {
            case 1:// Libra Britanica
                   conversion = dolares * valLibraPorDolar;
                   break;
            case 2:// Pesos Mexicanos
                   conversion = dolares * valPesoPorDolar;
                   break;       
            case 3:// Libra Britanica
                   conversion = dolares * valYenPorDolar;
                   break;
            default:// Error en Moneda
                   System.out.print("La Moneda indicada no es valida");
                   conversion = -1.0;                          
        }

        // Verifica si hubo conversion
        if (conversion>-1)   
        {
            // Despliega el Mensaje
            System.out.print("El Equivalente es de:"+conversion);
        }
           
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}