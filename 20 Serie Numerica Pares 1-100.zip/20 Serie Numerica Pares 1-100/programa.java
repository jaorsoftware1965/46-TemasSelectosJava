// -------------------------------------------------------
// Serie Numerica de Numeros pares entre 1 y 100
// -------------------------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{   

    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Mensaje
       System.out.println("Serie Numerica de Numeros Pares entre 1 y 100");

       // Ciclo para imprimir los numeros del 1 al 100
       for (int i=2; i<=100;i=i+2)
       {
           // Despliega el Numero
           System.out.print("["+i+"] ");    
       }
                  
       // Mensaje Final
       System.out.println("\nPrograma Terminado...");       

    }       
}