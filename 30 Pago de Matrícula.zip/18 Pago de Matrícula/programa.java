// -------------------------------------------------------
// PROBLEMA DE PAGO DE MATRICULA
// Programa 07
// A usted lo han seleccionado del centro de Computo para 
// trabajar en un programa interactivo para la oficina de
// tesorería.

// Desarrolle un programa para determinar el pago de la 
// matrícula. 
// La entrada(input) incluye el nombre del 
// estudiante, el numero de estudiante, y la cantidad de
// créditos matriculados.
// La salida(output) será el nombre del estudiante; el 
// numero del estudiante, y el pago de la matrícula
// Todo estudiante que tenga 12 créditos o mas, se considera
// un estudiante de tiempo completo, y pagara 2000 por su
// matrícula total. De lo contrario se considera un estudiante
// de tiempo parcial y se le cobrará 215 el crédito para
// determinar su pago de Matrícula.

// El Diseño de la pantalla debe ser similar a este:
// Cobro de la Matricula

// Entre el Nombre del Estudiante:_______
// Entre el Numero del Estudiante:_______
// Entre la Cantidad de Créditos Matriculados:_____

// Su pago de Matrícula es:_______

// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   

    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
                
        // Mensajes
        System.out.println("Cobro de Matricula\n");
         
        System.out.print("Entre el Nombre del Estudiante:");
        String nombre = oEntrada.nextLine(); 
        
        System.out.print("Entre el Numero del Estudiante:");
        String numero = oEntrada.nextLine(); 
        
        System.out.print("Entre la Cantidad de Creditos Matriculados:");
        Integer creditos = oEntrada.nextInt(); 
        System.out.print("\n");
        // Variable para el Importe
        Integer importe;

        // Verifica cantidad de creditos
        if (creditos>=12)   
        {
            // Establece el Importe
            importe = 2000;
        }
        else
        {
            // Calcula el importe
            importe = creditos * 215;
        }

        // Desplegamos la Salida
        System.out.println("Cobro de Matricula\n");         
        System.out.println("Nombre del Estudiante:"+nombre);       
        System.out.println("Numero del Estudiante:"+numero);
        System.out.println("Cantidad de Creditos Matriculados:"+creditos);
        System.out.println("");
        System.out.println("Su pago de Matricula es:"+importe);
                   
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}