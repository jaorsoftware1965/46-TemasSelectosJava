// -------------------------------------------
// Tareas y Temas Selectos de Java
// Recursividad
// Función Recursiva que suma los numeros
// Pares en una cadena y resta los impares
// Ejemplo:
// Cadena : 436
//                   
// fnSumaPares (436) =  4 + fnSumaNumeros(36) = 7
//                               3
// fnSumaPares (36)  = -3 + fnSumaNumeros(6) = 3
//                                6 
// fnSumaPares (6)   =  6 + fnSumaNumeros("") = 6
//                                0          
// ------------------------------------------

// Clase se debe llamar igual que el archivo
public class programa
{
  static int fnSumaPares(String cadenaNumeros)
  {
    // Variable para el resultado
    int resultado = 0;
    
    // Verifico que la cadena no sea vacia
    if (cadenaNumeros.length() > 0)
    {
       // Mensaje de que cadena está evaluando
       System.out.println("Evaluando:"+cadenaNumeros);

       // Variable para el Caracter
       String caracter;
       int    numero;
       String nvaCadena;
       
       // Obtiene el caracter en posición 0
       caracter = cadenaNumeros.substring(0, 1);

       // Lo convierto
       numero = Integer.parseInt(caracter);

       // Obtengo la Nueva Cadena
       nvaCadena = cadenaNumeros.substring(1);

       // Verifico si es par
       if (numero % 2 == 0)       
          // Si es
          resultado = numero + fnSumaPares(nvaCadena);       
       else
          // No es
          resultado = (numero*-1) + fnSumaPares(nvaCadena);       
       
       // Imprimimos el Resultado
       System.out.println("Resultado de "+cadenaNumeros+" es:"+resultado);
    }   

    // Retorna el valor
    return resultado;
  }

  // Función main que es obligatorio
  public static void main(String args[])
  {   
    // Mensaje
    System.out.println("Recursividad en Java");
    String cadena="436";
    System.out.println("Suma de Pares; Resta de Impares en "+cadena);
    System.out.println(fnSumaPares(cadena));
  }
}