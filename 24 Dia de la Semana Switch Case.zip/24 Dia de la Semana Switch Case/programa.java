// -------------------------------------------------------
// Tema: SWITCH / CASE STATEMENT
// 1. Desarrollar un programa que devuelva el nombre del 
// día de la semana siguiendo un orden de correspondencia 
// (1, 2, 3...7) para (lunes, martes, miércoles... 
// domingo) respectivamente. 
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Mensaje de Soliccitud
        System.out.println("PROGRAMA DE LOS DIAS");
        System.out.println("====================");
        System.out.print("Entre un Numero del 1 al 7:");
        Integer numero  = oEntrada.nextInt(); 
        
        // Valida el Numero
        if (numero < 1 || numero >7)
        {
            System.out.println("Error en Numero.");
        }
        else
        {
            // Evaluamos con switch
            switch(numero)
            {
                case 1:// Lunes
                       System.out.println("El dia es Lunes");
                       break;
                
                case 2:// Martes
                       System.out.println("El dia es Martes");
                     break;
                
                case 3:// Miercoles
                       System.out.println("El dia es Miercoles");
                       break;      
                
                case 4:// Jueves
                       System.out.println("El dia es Jueves");
                       break;

                case 5:// Viernes
                       System.out.println("El dia es Viernes");
                       break;       

                case 6:// Sabado
                       System.out.println("El dia es Sabado");
                       break;   
                
                case 7:// Domingo
                       System.out.println("El dia es Domingo");
                       break;
            }            
        }

        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}