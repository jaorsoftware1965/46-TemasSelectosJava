/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolsitaDeOro;

import javax.swing.JOptionPane;

/**
 *
 * @author jaor
 */
public class CuentaPlazoFijo extends CuentaBancaria
{
    // Constructor
    public CuentaPlazoFijo(String numero, float saldoInicial, float interes )
    {
        // Llama al constructor padre
        super(numero, saldoInicial,interes);
    }
    
    public boolean retirar (float cantidad, boolean expiro)
    {   
        boolean resultado;
        // Verifica
        if (cantidad > saldo)
        {
            resultado = false;
            JOptionPane.showMessageDialog(null, 
                                         "No tienes fondos suficientes",
                                         "WARNING_MESSAGE", 
                                         JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            if (expiro)
            {
                // No hay recargos
                this.retirar(cantidad, 0.0f, expiro);                
            }
            else
            {
                // Si hay recargos
                this.retirar(cantidad, 0.5f, expiro);                
            }        
            resultado = true;
        }        
        
        return resultado;
    }    
}
