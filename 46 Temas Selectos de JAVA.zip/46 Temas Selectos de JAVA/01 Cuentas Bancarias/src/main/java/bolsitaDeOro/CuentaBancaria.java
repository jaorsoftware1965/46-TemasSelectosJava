/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolsitaDeOro;

/**
 *
 * @author jaor
 */
public class CuentaBancaria {
    // Propiedades
    protected String  numero; 
    protected float   saldo;  
    protected int     transacciones;
    protected float   interes;
    
    // Constructor
    public CuentaBancaria (String numero, float saldoInicial, float interes)
    {
        // Inicializa datos de la cuenta
        this.numero    = numero;
        this.saldo     = saldoInicial;
        this.interes   = interes;
        transacciones  = 0;
    }

    /**
     * @return the numero
     */
    protected String getNumero() {
        return numero;
    }


    /**
     * @return the saldo
     */
    protected float getSaldo() {
        return saldo;
    }


    /**
     * @return the transacciones
     */
    protected int getTransacciones() {
        return transacciones;
    }

    /**
     * @param transacciones the transacciones to set
     */
    protected void setTransacciones(int transacciones) {
        this.transacciones = transacciones;
    }
    
    protected void aplicarInteres()
    {
        float interesAplicar;
        interesAplicar = saldo * interes;
        saldo = saldo + interesAplicar;
    }
    
    // Metodo para depositar
    protected void depositar(float cantidad)
    {
        // Incrementa el Saldo
        saldo = saldo + cantidad;
    }
    
    // Método para retirar
    protected void retirar (float cantidad, float cargo, boolean expiro)
    {
        float cargoAplicar;
        
        // VAerifica si exporo
        if (expiro)
        {
            // aplica sin cargo
            saldo = saldo - cantidad;
        }
        else
        {
            // Calcula el cargo a aplicar
            cargoAplicar = cantidad * cargo;
            saldo = saldo - cantidad - cargoAplicar;
        }
        
        // Incrementa el Contador de transacciones
        transacciones++;        
    }
}
