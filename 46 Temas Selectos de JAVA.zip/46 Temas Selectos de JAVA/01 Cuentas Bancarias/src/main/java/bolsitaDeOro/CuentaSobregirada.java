/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolsitaDeOro;

import javax.swing.JOptionPane;

/**
 *
 * @author jaor
 */
public class CuentaSobregirada extends CuentaBancaria
{
    // Constructor
    public CuentaSobregirada(String numero, float saldoInicial, float interes )
    {
        // Llama al constructor padre
        super(numero, saldoInicial,interes);
    }
    
    public void retirar (float cantidad, boolean expiro)
    {                
        // Verifica cuantas transacciones hay
        if (this.transacciones>5)
        {
            //aumenta la cantidad del retiro en 3
            cantidad = cantidad + 3;                                            
        }
        
        // Verifica sobregiro
        if (cantidad > saldo)
        {
            JOptionPane.showMessageDialog(null, 
                                         "Has sobregirado la cuenta",
                                         "WARNING_MESSAGE", 
                                         JOptionPane.WARNING_MESSAGE);
        }
        // retira sin cargo y sin expirar
        this.retirar(cantidad, 0.0f, expiro);
    }
    
// Verifica que el saldo sea menor
    public void cargoPorSobregiro()
    {
        float cargo;
        
        // Verifica que el saldo sea negativo
        if (saldo <0)
        {
            // Calcula el Cargo
            cargo = saldo * 0.20f ;
            
            // Aplica el Cargo
            saldo = saldo + cargo;
        }        
        else
           JOptionPane.showMessageDialog(null, 
                                         "La cuenta no tiene sobregiro",
                                         "WARNING_MESSAGE", 
                                         JOptionPane.WARNING_MESSAGE);       
    }
    
    
    
}
