// -------------------------------------------------------
// PROBLEMAS INTERACTIVO DE VENTAS
// Programa 05
// A usted lo han seleccionado del Centro de Computo, para
// trabajar en un programa interactivo para la oficina de
// Ventas
// Desarrolle un programa para determinar la comisión pagada
// por cada vendedor. La entrada(input) incluye el numero
// del vendedor, el nombre del Vendedor, y la cantidad vendida
// La Salida(output) será el Nombre del Vendedor y la comisión
// pagada.
// Utilice la tabla a continuación para calcular la comisión

// Cantidad         Comisión
// 10,001 o Mas     10%
// 10,000 - 7,000    7%
//  6,999 - 4,000    5%
//  3,999 - 1,000    3%
// Menos de 1,000    2%

// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
                
        // Mensaje de Soliccitud        
        System.out.print("Entre el Numero del Vendedor:");
        oEntrada.nextLine(); 
        System.out.print("Entre el Nombre del Vendedor:");
        String nombre   = oEntrada.nextLine(); 
        System.out.print("Cantidad vendida            :");
        Double cantidad = oEntrada.nextDouble(); 
        Double comision;
        
        // Verifica el tipo de Mensaje
        if (cantidad >10000)
           comision = cantidad * .10;
        else
        if (cantidad >= 7000)
           comision = cantidad * .07;
        else
        if (cantidad >= 4000)
           comision = cantidad * .05;
        else   
        if (cantidad >= 1000)
           comision = cantidad * .03;   
        else
           comision = cantidad * .02;   
        
        // Despliega el Nombre del vendedor y la comisión
        System.out.println("");        
        System.out.print(nombre);        
        System.out.print(",su comision pagada es:");        
        System.out.println(comision);        
           
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}