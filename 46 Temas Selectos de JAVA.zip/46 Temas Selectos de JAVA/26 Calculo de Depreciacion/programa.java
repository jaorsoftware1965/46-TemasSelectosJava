// -------------------------------------------------------
// Métodos de depreciación.
// STRAIGHT LINE METHOD.
// Asumiendo que la depreciación del equipo es $900.00 al 
// añoo, determine la siguiente tabla.

// INITIAL COST OF EQUIPMENT $ 10,000.00 
// SALVAGE VALUE             $  1,000.00 
// LIFETIME IN YEAR                10

//  Output:
//  PERIOD    STRAIGHT LINEMETHOD
//  0           $ 10,000.00 
//  1           $  9,100.00 
//  2           $  8,200.00 
//  3           $  7,300.00 
//  4           $  6,400.00 
//  5           $  5,500.00 
//  6           $  4,600.00 
//  7           $  3,700.00 
//  8           $  2,800.00 
//  9           $  1,900.00 
// 10           $  1,000.00
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("CALCULO DE DEPRECIACION");
        System.out.println("=======================");

        // Variables para datos
        Double  costoEquipo       = 10000.00;
        Double  depreciacionAnual =   900.00;
        
        // Desplegamos Información Inicial
        System.out.println("Costo Inicial del Equipo:"+costoEquipo);
        System.out.println("Valor a Salvar          :1000");
        System.out.println("Tiempo de vida en anios  :10");
        System.out.print("\nOutput:\n");

        System.out.println("Periodo    Straight Line Method\n");
        
        // Ciclo para realizar la depreciación en 10 anios
        for (int anio=0; anio<=10; anio++)
        {
            // Imprime
            System.out.println(anio+"          $ "+costoEquipo);

            // Depreciamos
            costoEquipo = costoEquipo - depreciacionAnual;
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}