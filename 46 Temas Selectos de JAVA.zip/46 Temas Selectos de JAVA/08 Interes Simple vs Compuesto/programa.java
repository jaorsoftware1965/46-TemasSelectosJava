// -------------------------------------------------------
// INTERES SIMPLE vs COMPUESTO
// Cuando 1000 son invertidos al 5% de interes simple anual;
// la Cantidad aumenta 50 cada año.
// Cuando la misma cantidad, es invertida al 5% de interés
// compuesto anual, la cantidad en el final de cada año es
// de 1.05 veces la cantidad del comienzo de ese año.
// Despliegue la cantidad para 9 años para una inversión de
// de 1000 en interés simpl y para interes compuesto
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("INTERES COMPUESTO VS SIMPLE");
        System.out.println("===========================");

        // Variables para datos
        Double  valorInvertidoSimple    = 1000.00;
        Double  valorInvertidoCompuesto = 1000.00;
        Double  interesAnual            = 0.05;
                
        System.out.println("ANIO  INTERES SIMPLE    INTERES COMPUESTO\n");
        
        // Ciclo para realizar la depreciación en 10 anios
        for (int anio=1; anio<=9; anio++)
        {
            // Calcula el Interes Simple
            valorInvertidoSimple = valorInvertidoSimple + (1000*interesAnual);
            
            // Calcula el Interes Compuesto
            valorInvertidoCompuesto = valorInvertidoCompuesto + (valorInvertidoCompuesto*interesAnual);
            
            // Imprime
            System.out.println(anio+"     $ "+valorInvertidoSimple+"          $ "+valorInvertidoCompuesto);
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}