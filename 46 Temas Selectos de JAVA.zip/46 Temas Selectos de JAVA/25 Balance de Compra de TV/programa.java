// -------------------------------------------------------
// Desarrolle el programa para cada problema verbal.
// 1. Un TV se compró con un préstamo de $580.00, pagando 
// $116.00 en los próximos 5 meses. 
// Presente en forma de tabla, el balance del préstamo al 
// final de cada mes.
// 1 $464.00
// 2 $348.00
// 3 $232.00
// 4 $116.00
// 5 $000.00
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("PROGRAMA DE BALANCE");
        System.out.println("==========================");

        // Variable del Importe de la TV
        Double importeTV   = 580.00;

        // Variable de pago Mensual
        Double pagoMensual = 116.00;

        // Variable para contar los meses
        Integer mes=0;

        // Ciclo para simular el pagoi mensual
        while (importeTV>0)
        {
            // Decrementa el importe de la TV
            importeTV = importeTV - pagoMensual;

            // Incrementa el Mes
            mes++;

            // Imprimimos
            System.out.println(mes+"     $"+importeTV);
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}