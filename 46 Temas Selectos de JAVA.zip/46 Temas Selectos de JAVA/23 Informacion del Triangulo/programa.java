// -------------------------------------------------------
// Desarrollar un programa que calcule: 
// - El valor del área de un triángulo, dada la base y la 
//   altura.
// - El valor de la base de un triángulo dada la altura y 
//   el área.
// - El valor de la altura de un triángulo dada la base y 
//   el área.

// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("PROGRAMA DE LOS TRIANGULOS");
        System.out.println("==========================");

        // Declaramos variables
        Double base, altura, area;

        // Desplegamos Menu
        System.out.println("1.- Para calcular el area de un Triangulo");
        System.out.println("2.- Para calcular la base");
        System.out.println("3.- Para calcular la altura");
        System.out.print("\nEntre la opcion deseada:");
        Integer opcion  = oEntrada.nextInt(); 

        // Valida opcion
        if (opcion < 1 || opcion > 3)
        {
            // Mensaje de Error
            System.out.println("Error en Opción");
        }
        else
        {

            // Evalua
            switch (opcion)
            {
                case 1:// Area
                       System.out.print("Entre la base:");
                       base  = oEntrada.nextDouble(); 

                       System.out.print("Entre la altura:");
                       altura  = oEntrada.nextDouble(); 

                       // Calcula y despliega
                       area = base * altura / 2;

                       // Despliega
                       System.out.print("El area del Triangulo es:"+area);

                       // Sale
                       break;
                
                case 2:// base
                       System.out.print("Entre el area:");
                       area  = oEntrada.nextDouble(); 

                       System.out.print("Entre la altura:");
                       altura  = oEntrada.nextDouble(); 

                       // Calcula y despliega
                       base  = area / altura * 2;

                       // Despliega
                       System.out.print("La base del Triangulo es:"+ base);

                       // Sale
                       break;

                case 3:// Altura
                       System.out.print("Entre el area:");
                       area  = oEntrada.nextDouble(); 

                       System.out.print("Entre la base:");
                       base  = oEntrada.nextDouble(); 

                       // Calcula y despliega
                       altura = area / base * 2;

                       // Despliega
                       System.out.print("La altura del Triangulo es:"+altura);

                       // Sale
                       break;       
            }
        }

        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}