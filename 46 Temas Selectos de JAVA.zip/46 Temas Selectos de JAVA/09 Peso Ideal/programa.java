// -------------------------------------------------------
// PESO IDEAL
// De acuerdo a la Escuela Médica de Stanford, el peso ideal
// para una mujer, es encontrado multiplicando su altura
// en pulgadas por 3,5 y restando 108.
// El peso ideal para un hombre, se calcula multiplicando
// su altura en pulgadas por 4 y restando 128
// Despliegue una tabla que refleje el peso ideal para 
// hombres y mujeres para un rango de estaturas de 62 a 70
// pulgadas
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("PESO IDEAL");
        System.out.println("=======================");
        
        // Varriables
        Double pesoMujer, pesoHombre;

        System.out.println("ALTURA    PESO-MUJER  PESO-HOMBRE\n");
        
        // Ciclo para realizar la depreciación en 10 anios
        for (int altura=62; altura<=70; altura++)
        {
            // Calcula peso de la Mujer
            pesoMujer  = (altura * 3.5) - 108;
            pesoHombre = (altura * 4.0) - 128;

            // Imprime
            System.out.println(altura + "        "+pesoMujer+ "       " + pesoHombre);
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}