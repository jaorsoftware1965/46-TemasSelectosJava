// -------------------------------------------------------
// Realice un Programa en Java que Realice conversiones
// de las siguientes Monedas a Dolar Americano
// Peso Chileno
// Dolar Canadiense
// Euro
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Valores de las Monedas
    static final private Double valEuroPorDolar         =   1.22;
    static final private Double valPesoChilenoPorDolar  = 715.10;
    static final private Double valCanadiensePorDolar   =   0.82;

    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
                
        // Mensajes
        System.out.println("Conversion a Dolar Americano, desde");
        System.out.println("1.- Euros");
        System.out.println("2.- Peso Chileno");
        System.out.println("3.- Dolar Canadiense");
        System.out.println("");
         
        System.out.print("Seleccione Moneda: 1,2,3:");
        Integer moneda = oEntrada.nextInt(); 
        
        System.out.print("Entre la Cantidad :");
        Double  cantidad = oEntrada.nextDouble(); 

        // Variable para conversion
        Double conversion = 0.0;
        
        // Verifica la Moneda
        switch (moneda)
        {
            case 1: // Euro
                   conversion = cantidad * valEuroPorDolar;
                   break;
            case 2: // Pesos Chilenos
                   conversion = cantidad * valPesoChilenoPorDolar;
                   break;       
            case 3:// Dolar Canadiense
                   conversion = cantidad * valCanadiensePorDolar;
                   break;
            default:// Error en Moneda
                   System.out.print("La Moneda indicada no es valida");
                   conversion = -1.0;                          
        }

        // Verifica si hubo conversion
        if (conversion>-1)   
        {
            // Despliega el Mensaje
            System.out.print("El Equivalente es de:"+conversion);
        }
           
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}