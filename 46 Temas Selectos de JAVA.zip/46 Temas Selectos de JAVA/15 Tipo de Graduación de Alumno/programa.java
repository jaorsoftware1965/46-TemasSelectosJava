// -------------------------------------------------------
// PROBLEMAS VERBALES (Condiciones Multiples)
// Programa 04
// Prepare un Programa Interactivo para determinar si el 
// estudiante se graduará con honores o no.
// El Programa debe de permitir la entrada del nombre y GPA 
// del estudiante
// a) Debe presentar el mensaje "Sum cum laude" si el GPA 
//    del estudiante es mayor o igual a 3.9
// b) Debe presentar el mensaje "Magna cum laude" si el GPA 
//    del estudiante es mayor o igual a 3.6
// c) Debe presentar el mensaje "Cum laude" si el GPA del 
//    estudiante es mayor o igual a 3.3
// d) Debe presentar el mensaje "Se gradua sin Honores" si 
//    el GPA del estudiante es menor a 3.3
// 
// Salida Esperada
// Universidad Ana G. Mendaz
// Recinto de Carolina
// Oficina de Registraduría

// Entre el Nombre del Estudiante: Juan Perez
// Entre el GPA del Estudiante: 3.7

// El Mensaje es:Magna Cum Laude
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Titulares
        System.out.println("Universidad Ana G. Mendez");
        System.out.println("Recinto de Carolina");
        System.out.println("Oficina de Registraduria\n");

        // Mensaje de Soliccitud
        System.out.print("Entre el Nombre del Estudiante:");
        oEntrada.nextLine(); 
        
        System.out.print("Entre el GPA del Estudiante:");
        Double gpa  = oEntrada.nextDouble(); 

        System.out.println("");
        System.out.print("El Mensaje es:");
        // Verifica el tipo de Mensaje
        if (gpa >= 3.9)
           System.out.println("Sum cum laude");        
        else
        if (gpa >= 3.6)
           System.out.println("Magna cum laude");        
        else
        if (gpa >= 3.3)
           System.out.println("Cum laude");        
        else
           System.out.println("Se gradua sin Honores");        
               
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}