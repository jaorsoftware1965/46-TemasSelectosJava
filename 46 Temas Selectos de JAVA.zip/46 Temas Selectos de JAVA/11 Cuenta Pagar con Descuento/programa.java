// -------------------------------------------------------
// PROBLEMAS VERBALES (Procesos Secuenciales)
// Programa 02
// El Departamento de tiendas necesitar desarrollar un 
// programa para determinar la cuenta a pagar(factura) de 
// un cliente. 
// La entrada (input) incluye el Nombre del Cliente, 
// Descripcion del Articulo, cantidad y precio.
// La Salida(output) será el nombre del Cliente y la cuenta 
// a Pagar (factura) despues de un 10% de descuento y 
// un 5% de impuestos por venta
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Mensaje de Soliccitud
        System.out.println("Nombre:");
        String nombre   = oEntrada.nextLine(); 

        System.out.println("Articulo:");
        String articulo = oEntrada.nextLine(); 

        System.out.println("Cantidad:");
        Integer cantidad = oEntrada.nextInt(); 

        System.out.println("Precio:");
        Double precio = oEntrada.nextDouble(); 

        // Obtenemos el Importe
        Double importe = cantidad * precio;

        // Hacemos un Descuento del 10%
        importe = importe - (importe * .10);

        // Calculamos el importe con Impuesto
        importe = importe * 1.05;

        // Imprimimos
        System.out.println("Factura ----------------------------");        
        System.out.println("Nombre   :"+nombre);        
        System.out.println("Articulo :"+articulo);        
        System.out.println("Cantidad :"+cantidad);        
        System.out.println("Precio   :"+precio);        
        System.out.println("El Importe de la Factura es:"+importe);        
        System.out.println("------------------------------------");        
                
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}