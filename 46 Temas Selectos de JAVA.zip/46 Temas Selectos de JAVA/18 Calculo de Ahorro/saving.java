// -------------------------------------------------------
// Tarea de Java 03
// Calculo de Cuenta de Ahorros
// -------------------------------------------------------
	
// Librerías
import javax.swing.*;

public class saving extends JFrame
{
	// Propiedades de la Clase
	private JLabel lblBalance;
	private JList  lstBalance;

	// Constructor
    public saving(Double valor) 
	{
		// Establece Null Layout
        setLayout(null);
        
		// crea una etiqueta
		lblBalance = new JLabel("Balance:");
        lblBalance.setBounds(10,20,300,30);
        add(lblBalance);

		// Crea la Lista
		lstBalance = new JList();

		// Crea el Modelo para la Lista
        DefaultListModel modelo = new DefaultListModel();

		// Agrega el Balance a JList
        modelo.addElement(String.valueOf(valor));
        lstBalance.setModel(modelo);

        // Dimensiones del JList
		lstBalance.setBounds(100,20,100,30);

        // Lo agrega a la Ventana
        add(lstBalance);
    }

    public static void main(String[] ar) 
	{
        // Declara las variables indicadas en el ejercicio
        // a) Declarar la variable balance de tipo Double
        double balance;

        // b) Asignar el valor 100 a la variable balance
        balance = 100;

        // c) Incrementar el valor de la variable balance en 5%
        // d) Incrementar el valor de la variable balance en 5%
        // e) Incrementar el valor de la variable balance en 5%
        balance = balance *1.05;
        balance = balance *1.05;
        balance = balance *1.05;
        		
        // f) Desplegar el valor de balance redondeado a 2 decimales, en un listbox
        balance = Math.round(balance*100.0)/100.0;
		
		// Creamos la Ventana pasando el valor como parametros
        saving ventana = new saving(balance);

		// Colocamos el titulo
		ventana.setTitle("Calculo de Balance en Cuenta de Ahorros");
		
		// Establecemos dimensiones
        ventana.setBounds(10,20,400,300);

		// La hacemos visible
        ventana.setVisible(true);

		// Establecemos que sucede al cerrar la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}