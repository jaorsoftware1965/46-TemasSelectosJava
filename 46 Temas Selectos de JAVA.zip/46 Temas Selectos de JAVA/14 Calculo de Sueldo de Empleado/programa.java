// -------------------------------------------------------
// PROBLEMAS VERBALES (Procesos Secuenciales)
// Programa 03
// Prepare un programa donde acepte como datos de Entrada 
// el Numero del Empleado, Nombre del Empleado, las Horas 
// Trabajadas, y la paga por hora.
// Determine el Salario Bruto, descuento de Seguro Social
// (7.86%) descuento de Income Tax (8%) y el Salario Neto.
// La Salida (output), será el salario Bruto, Total de 
// Descuentos, y el Sueldo Neto
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Mensaje de Soliccitud
        System.out.println("Capture los datos del Empleado");
        
        System.out.println("Numero:");
        Integer numero  = oEntrada.nextInt(); 

        // Limpia el Buffer
        oEntrada.nextLine(); 

        System.out.println("Nombre:");
        String nombre   = oEntrada.nextLine(); 

        System.out.println("Horas Trabajadas:");
        Integer horas   = oEntrada.nextInt(); 

        System.out.println("Pago por Hora:");
        Double pago = oEntrada.nextDouble(); 
        
        // Obtenemos el Salario Bruto
        Double salario = horas * pago;

        // Cálculo del Seguro Social
        Double seguro = salario * .0786;

        // Cálculo del Impuesto
        Double impuesto = salario * .08;

        // Calculo del Salario Neto
        Double salarioNeto = salario - seguro - impuesto;


        // Imprimimos
        System.out.println("Nomina de Empleado");        
        System.out.println("Numero        :"+numero);        
        System.out.println("Nombre        :"+nombre);        
        System.out.println("Horas         :"+horas);        
        System.out.println("Pago/hora     :"+pago);        
        System.out.println("Salario Bruto :"+salario);        
        System.out.println("Seguro Social :"+seguro);        
        System.out.println("Impuesto      :"+impuesto);        
        System.out.println("Total Descto  :"+(seguro+impuesto));        
        System.out.println("Salario Neto  :"+salarioNeto);        
                
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}