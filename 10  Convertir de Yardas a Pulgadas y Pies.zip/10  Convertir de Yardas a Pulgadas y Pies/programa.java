// -------------------------------------------------------
// PROBLEMAS VERBALES (Procesos Secuenciales)
// Programa 01
// Prepara un programa que acepte como entrada cualquier 
// numero y asuma que este numero representa la cantidad 
// en Yardas.
// Realice los procesos necesarios para convertir en Pies 
// y Pulgadas.
// La salida del programa serán los pies y pulgadas
// Datos
// 1 Yarda = 3 Pies
// 1 Yarda = 36 Pulgadas
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);
        
        // Mensaje de Soliccitud
        System.out.println("Capture valor en Yardas:");
        Double yardas  = oEntrada.nextDouble(); 

        // Convertimos a Pies
        Double pies = yardas * 3;
        System.out.println("El Valor en Pies es:"+pies);

        // Convertimos a Pulgadas
        Double pulgadas = yardas * 36;
        System.out.println("El Valor en Pulgadas es:"+pulgadas);
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("Programa Terminado...");       
    }       
}