/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prjeditor;

/**
 *
 * @author paul
 */
public class PrjEditor {

    public static void main(String[] args) 
    {
        // Mensaje de Inicio de la Aplicación
        System.out.println("Iniciando el editor ...");
        
        // Crea la forma del Editor y la ejecuta
        new frmEditor().setVisible(true);        
    }
}
