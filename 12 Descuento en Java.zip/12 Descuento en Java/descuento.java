// -------------------------------------------------------
// Tarea de Java 02
// Calculo de Descuento a Precio
// -------------------------------------------------------
	
// Librerías
import javax.swing.*;

public class descuento extends JFrame
{
	// Propiedades de la Clase
	private JLabel lblPrecio;
	private JList  lstPrecio;

	// Constructor
    public descuento(Double valor) 
	{
		// Establece Null Layout
        setLayout(null);
        
		// crea una etiqueta
		lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(10,20,300,30);
        add(lblPrecio);

		// Crea la Lista
		lstPrecio = new JList();

		// Crea el Modelo para la Lista
        DefaultListModel modelo = new DefaultListModel();

		// Agrega el precio a JList
        modelo.addElement(String.valueOf(valor));
        lstPrecio.setModel(modelo);

        // Dimensiones del JList
		lstPrecio.setBounds(100,20,100,30);

        // Lo agrega a la Ventana
        add(lstPrecio);
    }

    public static void main(String[] ar) 
	{
        // Declara las variables indicadas en el ejercicio
		// a) Declarar la variable price, discountPercent, and amount de tipo Double
        double price, discountPercent, amount;

        // b) Asignar el valor 19.95 a la variable price
        price = 19.95;

        // c) Asignar el valor de 30 a la variable discountPercent
        discountPercent = 30;

        // d) Asignar el valor de discountPercent dividido por 100 price y obtener descuento
        discountPercent = discountPercent / 100;

        // e) Decrementar el precio con el descuento
        price = price - (price * discountPercent);

        // f) Desplegar el valor de price redondeado a 2 decimales, en un listbox
        price = Math.round(price*100.0)/100.0;

		
		// Creamos la Ventana pasando el valor como parametros
        descuento ventana = new descuento(price);

		// Colocamos el titulo
		ventana.setTitle("Calculo de Precio con Descuento");
		
		// Establecemos dimensiones
        ventana.setBounds(10,20,400,300);

		// La hacemos visible
        ventana.setVisible(true);

		// Establecemos que sucede al cerrar la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}