// -------------------------------------------------------
// DEPRECIACIÓN DE UN AUTO
// Una regla general establece que UN automóvil de uso 
// persona se deprecia 15% cada año.
// Suponga que se compra un automóvil nuevo por 20000.
// Produzca una tabla que muestre el valor del auto al final 
// de cada año
// -------------------------------------------------------

// Importa las funciones
import java.util.Scanner;

// Clase se debe llamar igual que el archivo
public class programa
{   
    // Función main que es obligatorio
    public static void main(String args[])
    {
        // Creamos un objeto de la Clase
        Scanner oEntrada = new Scanner(System.in);        
        
        // Mensaje de Soliccitud
        System.out.println("DEPRECIACION AUTOMOVIL");
        System.out.println("=======================");

        // Variables para datos
        Double  valorAutomovil    = 20000.00;
        Double  depreciacionAnual = 0.15;
        
        // Depreciacion del Auto en 5 años
        System.out.println("Depreciacion del Auto en 5 anios\n");
        
        // Ciclo para realizar la depreciación en 10 anios
        for (int anio=1; anio<=5; anio++)
        {
            // Deprecia el Automovil
            valorAutomovil = valorAutomovil - (valorAutomovil*depreciacionAnual);
            // Imprime
            System.out.println(anio+":$"+valorAutomovil);
        }
        
        // Cerramos el Objeto
        oEntrada.close();
        
        // Mensaje Final
        System.out.println("\nPrograma Terminado...");       
    }       
}