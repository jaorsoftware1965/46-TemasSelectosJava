/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolsitaDeOro;

import javax.swing.JOptionPane;

/**
 *
 * @author jaor
 */
public class CuentaCheques extends CuentaBancaria
{
    // Constructor
    public CuentaCheques(String numero, float saldoInicial, float interes )
    {
        // Llama al constructor padre
        super(numero, saldoInicial,interes);
    }
    
    public boolean retirar (float cantidad, boolean expiro)
    {   
        boolean resultado;
        
        if (cantidad > saldo)
        {
            // Verifica cuantas transacciones hay
            if (this.transacciones>5)
            {   
                //aumenta la cantidad del retiro en 3
                cantidad = cantidad + 3;            
            }            
                    
            // retira sin cargo y sin expirar
            this.retirar(cantidad, 0.0f, expiro);
            resultado=true;
        }
        else
        {
            JOptionPane.showMessageDialog(null, 
                                          "No hay fondos suficientes",
                                          "WARNING_MESSAGE", 
                                          JOptionPane.WARNING_MESSAGE);
            resultado = false;
        }
        return resultado;
    }    
}
