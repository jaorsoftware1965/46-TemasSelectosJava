/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolsitaDeOro;

import javax.swing.JOptionPane;

/**
 *
 * @author jaor
 */
public class CuentaAhorros extends CuentaBancaria
{
    // Constructor
    public CuentaAhorros(String numero, float saldoInicial, float interes )
    {
        // Llama al constructor padre
        super(numero, saldoInicial,interes);
    }
    
    public boolean retirar (float cantidad)
    {
        // Variable de Resultado
        boolean resultado;
        
        // Verifica que pueda retirar
        if (cantidad<= saldo)
        {
           // retira sin cargo y sin expirar
           this.retirar(cantidad, 0.00f, true);
           resultado = true;
        }
        else
        {
            JOptionPane.showMessageDialog(null, 
                                         "No hay fondos suficientes",
                                         "WARNING_MESSAGE", 
                                         JOptionPane.WARNING_MESSAGE);            
            resultado = false;
        }
        return resultado;
    }
}
